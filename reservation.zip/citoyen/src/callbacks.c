#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include <gtk/gtk.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "gestiondereservation.h"
#include <glib.h>
void on_button1_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *numero;
    GtkWidget *button1;
    GtkWidget *button2;
    GtkWidget *button3;
    GtkWidget *button4;
    GtkWidget *duree;
    GtkWidget *matricule;
    GtkWidget *label;
    GtkWidget *spin_annee;
    GtkWidget *spin_mois;
    GtkWidget *spin_jour;
    GtkWidget *comboboxentry4;
    reservation res;
    Parking p;
    int choix;
    comboboxentry4 = lookup_widget(GTK_WIDGET(button), "comboboxentry4");
    numero = lookup_widget(GTK_WIDGET (button), "entry2");
    duree = lookup_widget(GTK_WIDGET (button),"entry3");
    matricule = lookup_widget(GTK_WIDGET (button), "entry4");
    label = lookup_widget(GTK_WIDGET (button), "label44");
    GtkWidget *motocycle = lookup_widget(GTK_WIDGET(button), "motocycle");
    GtkWidget *tricycle = lookup_widget(GTK_WIDGET(button), "tricycle");
    GtkWidget *voiture = lookup_widget(GTK_WIDGET(button), "voiture");
    GtkWidget *camion = lookup_widget(GTK_WIDGET(button), "camion");
   GtkWidget *radiobutton15 = lookup_widget(GTK_WIDGET(button), "radiobutton15");
GtkWidget *radiobutton16 = lookup_widget(GTK_WIDGET(button), "radiobutton16");
//spin structure??
    spin_annee=lookup_widget(GTK_WIDGET (button), "annee");
    spin_mois=lookup_widget(GTK_WIDGET (button), "mois");
    spin_jour=lookup_widget(GTK_WIDGET (button), "jour");
    res.stationnement = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_annee)) * 10000 +
                         gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_mois)) * 100 +
                         gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_jour));
    const char *duree_text = gtk_entry_get_text(GTK_ENTRY(duree));
    res.duree = atoi(duree_text);
    const char *numero_text = gtk_entry_get_text(GTK_ENTRY(numero));
    res.numero_reservation = atoi(numero_text);
   char duree_string[20];  // Taille à adapter en fonction de votre besoin
   strcpy(duree_string, gtk_entry_get_text(GTK_ENTRY(duree)));
   res.duree = atoi(duree_string);
    strcpy(res.matricule, gtk_entry_get_text(GTK_ENTRY(matricule)));
    strcpy(numero, gtk_entry_get_text(GTK_ENTRY(numero)));
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(motocycle))) {
        strcpy(res.type_vehicule, "motocycle");
    } else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(tricycle))) {
        strcpy(res.type_vehicule, "tricycle");
    } else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(voiture))) {
        strcpy(res.type_vehicule, "voiture");
    } else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(camion))) {
        strcpy(res.type_vehicule, "camion");
    }
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton15))) {
        strcpy(res.abonnement, "mensuel");
    } else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton16))) {
        strcpy(res.abonnement, "annuel");
    }
    strcpy(p.nom, gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry4)));
int e=ajouter_reservation("reservation.txt", res,p);
  if (!controle_saisie("reservation.txt", res)) {
        gtk_label_set_text(GTK_LABEL(label), "Erreur dans les données saisies");
	e=0;
        return;
    }
  if (e == 1) {
        gtk_label_set_text(GTK_LABEL(label), "Réservation ajoutée");
    } else {
        gtk_label_set_text(GTK_LABEL(label), "Échec de l'ajout de la réservation");
    }
}
void on_button2_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *numero2;
    GtkWidget *spin_annee2, *spin_mois2, *spin_jour2;
    GtkWidget *duree2, *motocycle2, *tricycle2, *voiture2, *camion2;
    GtkWidget *mensuel2, *annuel2, *matricule2, *label;
    GtkWidget *comboboxentry2;
    reservation res, nouv;
    Parking p;
    char num2[20], du2[20], filename[] = "reservation.txt";
    comboboxentry2 = lookup_widget(GTK_WIDGET(button), "comboboxentry2");
    numero2 = lookup_widget(GTK_WIDGET(button), "entry5");
    duree2 = lookup_widget(GTK_WIDGET(button), "entry6");
    motocycle2 = lookup_widget(GTK_WIDGET(button), "radiobutton17");
    tricycle2 = lookup_widget(GTK_WIDGET(button), "radiobutton18");
    voiture2 = lookup_widget(GTK_WIDGET(button), "radiobutton20");
    camion2 = lookup_widget(GTK_WIDGET(button), "radiobutton19");
    mensuel2 = lookup_widget(GTK_WIDGET(button), "radiobutton21");
    annuel2 = lookup_widget(GTK_WIDGET(button), "radiobutton22");
    matricule2 = lookup_widget(GTK_WIDGET(button), "entry7");
    label = lookup_widget(GTK_WIDGET(button), "label45");

    spin_annee2 = lookup_widget(GTK_WIDGET(button), "spinbutton15");
    spin_mois2 = lookup_widget(GTK_WIDGET(button), "spinbutton17");
    spin_jour2 = lookup_widget(GTK_WIDGET(button), "spinbutton20");

    strcpy(num2, gtk_entry_get_text(GTK_ENTRY(numero2)));
    strcpy(du2, gtk_entry_get_text(GTK_ENTRY(duree2)));
    strcpy(nouv.matricule, gtk_entry_get_text(GTK_ENTRY(matricule2)));

    nouv.stationnement = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_annee2)) * 10000 +
                         gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_mois2)) * 100 +
                         gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_jour2));
    nouv.duree = atoi(du2);
    nouv.numero_reservation = atoi(num2);

    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(motocycle2))) {
        strcpy(nouv.type_vehicule, "motocycle2");
    } else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(tricycle2))) {
        strcpy(nouv.type_vehicule, "tricycle2");
    } else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(voiture2))) {
        strcpy(nouv.type_vehicule, "voiture2");
    } else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(camion2))) {
        strcpy(nouv.type_vehicule, "camion2");
    }

    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(mensuel2))) {
        strcpy(nouv.abonnement, "mensuel2");
    } else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(annuel2))) {
        strcpy(nouv.abonnement, "annuel2");
    }

    res = chercher(filename, nouv.matricule);
    if (res.numero_reservation == -1) {
        gtk_label_set_text(GTK_LABEL(label), "Réservation introuvable.");
        return;
    }

    if (modifier_reservation(filename, res.numero_reservation, nouv)) {
        gtk_label_set_text(GTK_LABEL(label), "Réservation modifiée avec succées.");
    } else {
        gtk_label_set_text(GTK_LABEL(label), "échec de la modification de la réservation.");
    }
}

/*void setup_treeview_reservation(GtkWidget *treeview) {
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;

    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Matricule", renderer, "text", 0, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Type Véhicule", renderer, "text", 1, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Durée", renderer, "text", 2, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Abonnement", renderer, "text", 3, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Stationnement", renderer, "text", 4, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);
}

void fill_treeview_reservation(GtkWidget *treeview) {
    GtkListStore *store;
    GtkTreeIter iter;

    store = gtk_list_store_new(5, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING, G_TYPE_INT);

    gtk_list_store_append(store, &iter);
    gtk_list_store_set(store, &iter, 0, "123-ABC", 1, "Voiture", 2, 2, 3, "Mensuel", 4, 20241210, -1);

    gtk_list_store_append(store, &iter);
    gtk_list_store_set(store, &iter, 0, "456-DEF", 1, "Camion", 2, 5, 3, "Annuel", 4, 20241215, -1);

    gtk_list_store_append(store, &iter);
    gtk_list_store_set(store, &iter, 0, "789-GHI", 1, "Motocycle", 2, 1, 3, "Mensuel", 4, 20241218, -1);

    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
    g_object_unref(store);
}*/
void setup_treeview_columns(GtkTreeView *treeview) {
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;

	// Remove any existing columns
	while (gtk_tree_view_get_column(treeview, 1)) {
	gtk_tree_view_remove_column(treeview, gtk_tree_view_get_column(treeview, 1));
	}
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MATRICULE", renderer, "text", 0, NULL);
	gtk_tree_view_append_column(treeview, column);
	column = gtk_tree_view_column_new_with_attributes("NUMERO", renderer, "text", 1, NULL);
   	gtk_tree_view_append_column(treeview, column);
	column = gtk_tree_view_column_new_with_attributes("STATIONNEMENT", renderer, "text", 2, NULL);
    	gtk_tree_view_append_column(treeview, column);
	column = gtk_tree_view_column_new_with_attributes("DUREE", renderer, "text", 3, NULL);
    	gtk_tree_view_append_column(treeview, column);
	column = gtk_tree_view_column_new_with_attributes("TYPE", renderer, "text", 4, NULL);
    	gtk_tree_view_append_column(treeview, column);
	}
void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
	{
GtkWidget *numero_entry = lookup_widget(GTK_WIDGET(button), "entry_matricule");
    GtkWidget *treeview = lookup_widget(GTK_WIDGET(button), "treeview_reservation");

    if (!numero_entry || !GTK_IS_ENTRY(numero_entry)) {
        g_print("Error: numero entry widget not found or invalid.\n");
        return;
    }

    if (!treeview || !GTK_IS_TREE_VIEW(treeview)) {
        g_print("Error: TreeView widget not found or invalid.\n");
        return;
    }

    const char *numero_text = gtk_entry_get_text(GTK_ENTRY(numero_entry));

    if (!numero_text || strlen(numero_text) == 0) {
        g_print("Error: Please enter a valid numero.\n");
        return;
    }

    
    reservation result = chercher("reservation.txt", numero_text);

    GtkListStore *store = GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(treeview)));
    if (!store) {
        store = gtk_list_store_new(5,
                                   G_TYPE_INT,      
                                   G_TYPE_STRING,   
                                   G_TYPE_INT,      
                                   G_TYPE_INT,      
                                   G_TYPE_STRING);  
    } else {
        gtk_list_store_clear(store); 
    }

    if (result.numero_reservation != -1) {
        GtkTreeIter iter;
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
                           0, result.numero_reservation,   
                           1, result.matricule,            
                           2, result.stationnement,        
                           3, result.duree,                
                           4, result.type_vehicule,        
                           -1);
    } else {
        g_print("No reservation found with numero: %s\n", numero_text);
    }

    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
    g_object_unref(store);
    setup_treeview_columns(GTK_TREE_VIEW(treeview));
}

	





void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *treeview = lookup_widget(GTK_WIDGET(button), "treeview_reservation");
    
    GtkWidget *tree = lookup_widget(GTK_WIDGET(button), "treeview_reservation");

    if (!GTK_IS_TREE_VIEW(tree)) {
        g_warning("Erreur : treeview_reservation n'est pas un TreeView valide.");
        return;
    }

    
    setup_treeview_columns(GTK_TREE_VIEW(tree));

    afficher_tous_les_reservations(GTK_TREE_VIEW(tree));
}


void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *entry_numero_reservation = lookup_widget(GTK_WIDGET(button), "entry_numero_reservation");

        GtkWidget *label = lookup_widget(GTK_WIDGET(button), "label46");

	 const char *numero_reservation = gtk_entry_get_text(GTK_ENTRY(entry_numero_reservation));
	if (numero_reservation == NULL || strlen(numero_reservation) == 0) {
    	gtk_label_set_text(GTK_LABEL(label), "Please enter a valid numero.");
    	return;
	}
	int result = supprimer_reservation_par_num("reservation.txt", (char *)numero_reservation);

	 if (result == 1) {
        
        gtk_label_set_text(GTK_LABEL(label), "reservation deleted successfully.");
	} else {
        
        gtk_label_set_text(GTK_LABEL(label), "numero not found.");
    }
}


void
on_display_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
Parking parkings[100];  
    int nombre_parkings = 0;
    charger_parkings(parkings, &nombre_parkings);

    for (int i = 0; i < nombre_parkings; i++) {
        printf("Parking: %s, Places disponibles: %d\n", parkings[i].nom, parkings[i].places_disponibles);
    }

    GtkWidget *treeview = lookup_widget(GTK_WIDGET(button), "treeview1");
    if (!treeview) {
        printf("Erreur: TreeView non trouvé.\n");
        return;
    }

    GtkListStore *store = gtk_list_store_new(2, G_TYPE_STRING, G_TYPE_INT); 
    for (int i = 0; i < nombre_parkings; i++) {
        GtkTreeIter iter;
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter, 0, parkings[i].nom, 1, parkings[i].places_disponibles, -1);
    }

    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));

    g_object_unref(store);

    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;

    column = gtk_tree_view_column_new_with_attributes("Nom du parking", renderer = gtk_cell_renderer_text_new(), "text", 0, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    column = gtk_tree_view_column_new_with_attributes("Places disponibles", renderer = gtk_cell_renderer_text_new(), "text", 1, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);
}

void on_treeview_reservation_row_activated(GtkTreeView *treeview,
                                           GtkTreePath *path,
                                           GtkTreeViewColumn *column,
                                           gpointer user_data)
{
    GtkTreeIter iter;
    GtkTreeModel *model = gtk_tree_view_get_model(treeview);
    gint numero_reservation;

    if (gtk_tree_model_get_iter(model, &iter, path)) {

        gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 1, &numero_reservation, -1);

        char num_res_str[20];
        sprintf(num_res_str, "%d", numero_reservation); 

        if (supprimer_reservation_par_num("reservation.txt", num_res_str)) {
            g_print("Reservation avec le numéro %s supprimée avec succès.\n", num_res_str);
        } else {
            g_print("Échec de la suppression de la réservation %s.\n", num_res_str);
        }

        afficher_tous_les_reservations(treeview);
    }
}

