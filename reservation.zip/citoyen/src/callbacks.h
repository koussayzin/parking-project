#include <gtk/gtk.h>


void
on_motocycle_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_tricycle_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_voiture_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_camion_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_motocycle_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_tricycle_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_voiture_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_camion_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton16_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton15_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_motocycle_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_tricycle_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_voiture_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_camion_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton16_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton15_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_display_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_reservation_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
