#ifndef GESTIONDERESERVATION_H
#define GESTIONDERESERVATION_H
#include<stdio.h>
#include <gtk/gtk.h>
typedef struct {
    int jour;
    int mois;
    int annee;
} Date;

typedef struct {
    char matricule[20];
    int stationnement;
    int duree;
    char type_vehicule[20];
    char abonnement[20];
    int numero_reservation;
} reservation;
typedef struct {
    char nom[20];
    int places_disponibles;
} Parking;
    enum {
    NUMERO,
    MATRICULE,
    STATIONNEMENT,
    DUREE,     
    NOM,         
    DATE,        
    NATURE,      
    NUM_COLUMNS,  
    
    
   };
int ajouter_reservation(char *filename, reservation res,Parking p);
int controle_saisie(char *filename, reservation res);
void charger_parkings(Parking parkings[], int *nombre_parkings);
int modifier_reservation(char *filename, int numero_reservation, reservation nouv);
reservation chercher(char *filename, const char *matricule);
void abonnement(int choix_local, char *msg);
reservation chercher2(char *filename, char *matricule);
int supprimer_reservation_par_num(const char *filename, const char *numero_reservation);
void display_parking_by_matricule(GtkTreeView *treeview, const char *matricule);
void afficher_tous_les_reservations(GtkTreeView *treeview);
void setup_treeview_columns(GtkTreeView *treeview);
#endif
