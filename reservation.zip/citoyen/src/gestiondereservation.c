#include "gestiondereservation.h"
#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include <gtk/gtk.h>
#define COLUMNS 1
int ajouter_reservation(char *filename, reservation res,Parking p) {
    FILE *f = fopen(filename, "a");
    if (f != NULL) {
         fprintf(f, "%s %d %d %s %s %d %s\n", res.matricule, res.stationnement, res.duree, res.type_vehicule, res.abonnement, res.numero_reservation, p.nom);
        fclose(f);
        return 1;
    }else {
    return 0;
}
}
int controle_saisie(char *filename, reservation res) {
    FILE *f_err = fopen("erreurs.txt", "a");
    if (f_err == NULL) {
        return 0;
    }

    int valide = 1;

    if (strlen(res.matricule) == 0) {
        fprintf(f_err, "Erreur: Le matricule ne peut pas être vide.\n");
        valide = 0;
    }
    if (res.stationnement <= 0) {
        fprintf(f_err, "Erreur: La date de stationnement doit être valide.\n");
        valide = 0;
    }
    if (res.duree <= 0) {
        fprintf(f_err, "Erreur: La durée doit être un entier positif.\n");
        valide = 0;
    }
    if (res.numero_reservation <= 0) {
        fprintf(f_err, "Erreur: Le numéro de réservation doit être un entier positif.\n");
        valide = 0;
    }
    fclose(f_err);
    return valide;
}
void charger_parkings(Parking parkings[], int *nombre_parkings) {
    FILE *file = fopen("parking.txt", "r");
    if (file != NULL) {
        int i = 0, j, k;
        while (fscanf(file, "%s %d", parkings[i].nom, &parkings[i].places_disponibles) != EOF) {
            i++;
        }
        *nombre_parkings = i;
        fclose(file);      
        for (j = 0; j < *nombre_parkings - 1; j++) {
            for (k = j + 1; k < *nombre_parkings; k++) {
                if (parkings[j].places_disponibles < parkings[k].places_disponibles) {
                    Parking temp = parkings[j];
                    parkings[j] = parkings[k];
                    parkings[k] = temp;
                }
            }
        }
    }
}
int modifier_reservation(char *filename, int numero_reservation, reservation nouv) {
    int tr = 0;
    reservation res;
    Parking p;
    FILE *f = fopen(filename, "r");
    FILE *f2 = fopen("nouv.txt", "w");

    if (f == NULL || f2 == NULL) {
        perror("Erreur lors de l'ouverture des fichiers pour modification");
        return 0;
    }

    while (fscanf(f, "%s %d %d %s %s %d %s\n", res.matricule, &res.stationnement, &res.duree, res.type_vehicule, res.abonnement, &res.numero_reservation,p.nom) != EOF) {
        if (res.numero_reservation == numero_reservation) {
           fprintf(f2, "%s %d %d %s %s %d%s\n", nouv.matricule, nouv.stationnement, nouv.duree, nouv.type_vehicule, nouv.abonnement, nouv.numero_reservation,p.nom);
            tr = 1;
        } else {
            fprintf(f, "%s %d %d %s %s %d %s\n", res.matricule, res.stationnement, res.duree, res.type_vehicule, res.abonnement, res.numero_reservation, p.nom);

   
        }
    }
    fclose(f);
    fclose(f2);
    remove(filename);
    rename("nouv.txt", filename);
    printf("Fichier %s modifié avec succès\n", filename);
    return tr;
}
int supprimer_reservation_par_num(const char *filename, const char *numero_reservation) {
    FILE *f, *temp;
    char line[256];
    int found = 0;
    f = fopen(filename, "r");
    if (!f) {
        perror("Erreur d'ouverture du fichier");
        return 0;
    }
    temp = fopen("temp.txt", "w");
    if (!temp) {
        perror("Erreur d'ouverture du fichier temporaire");
        fclose(f);
        return 0;
    }
    while (fgets(line, sizeof(line), f)) {
        char matricule[20], num_res[20]; 
        sscanf(line, "%s %s", matricule, num_res); 

        if (strcmp(num_res, numero_reservation) != 0) {
            fputs(line, temp); 
        } else {
            found = 1; 
        }
    }

    fclose(f);
    fclose(temp);

    if (found) {
        remove(filename); 
        rename("temp.txt", filename); 
        return 1; 
    } else {
        remove("temp.txt"); 
        return 0; 
    }
}
reservation chercher(char *filename, const char *matricule)
 {
    reservation res;
    res.numero_reservation = -1;  
    FILE *f = fopen(filename, "r");
    if (f != NULL) {
        while (fscanf(f, "%s %d %d %s %s %d\n", res.matricule, &res.stationnement, &res.duree, res.type_vehicule, res.abonnement, &res.numero_reservation) != EOF) {


            if (strcmp(res.matricule, matricule) == 0) {
                fclose(f);
                return res;  
            }
        }
        fclose(f);
    }
    return res;  
}


int choix=1;
void abonnement(int choix_local, char *msg) {
    if (choix == 1) {
        strcpy(msg, "motocycle");
    } else if (choix_local == 2) {
        strcpy(msg, "tricycle");
    } else if (choix_local == 3) {
        strcpy(msg, "voiture");
    } else if (choix_local == 4) {
        strcpy(msg, "camion");
    }
}

void display_parking_by_matricule(GtkTreeView *treeview, const char *matricule) {
    reservation res;
    GtkListStore *store;
    GtkTreeIter iter;

    
    store = gtk_list_store_new(5,
                               G_TYPE_STRING,   
                               G_TYPE_INT,      
                               G_TYPE_INT,      
                               G_TYPE_INT,    
                               G_TYPE_STRING);  

    
    res = chercher("reservation.txt", matricule);

    
    if (res.numero_reservation != -1) {
        
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
                           0, res.numero_reservation,            
                           1, res.matricule,   
                           2, res.stationnement,        
                           3, res.duree,                
                           4, res.type_vehicule,        
                           -1);
    } else {
      
        g_print("Reservation not found for matricule: %s\n", matricule);
    }

    // Associer le modèle au TreeView
    gtk_tree_view_set_model(treeview, GTK_TREE_MODEL(store));

    // Libérer la mémoire utilisée par le store
    g_object_unref(store);
}
void afficher_tous_les_reservations(GtkTreeView *treeview) {
    FILE *f;
    GtkListStore *store;
    GtkTreeIter iter;
    GtkCellRenderer *renderer;

    char matricule[20], nature_vehicule[20], abonnement[10], parking[100];
    int numero_reservation, stationnement, duree;   
    store = gtk_list_store_new(7, 
                               G_TYPE_STRING,  
                               G_TYPE_INT,      
                               G_TYPE_INT,      
                               G_TYPE_STRING,  
                               G_TYPE_STRING,   
                               G_TYPE_INT,      
                               G_TYPE_STRING);  

    f = fopen("reservation.txt", "r");
    if (f == NULL) {
        g_warning("Erreur : Impossible d'ouvrir le fichier reservation.txt.");
        return;
    }
    char line[256];
    while (fgets(line, sizeof(line), f)) {
        line[strcspn(line, "\n")] = '\0';
        if (sscanf(line, "%19s %d %d %19s %9s %d %[^\n]", 
                   matricule, &stationnement, &duree, 
                   nature_vehicule, abonnement, &numero_reservation, parking) == 7) {
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter,
                               0, matricule,
                               1, stationnement,
                               2, duree,
                               3, nature_vehicule,
                               4, abonnement,
                               5, numero_reservation,
                               6, parking,
                               -1);
        } else {
            g_warning("Erreur de format dans la ligne : %s", line);
        }
    }
    fclose(f);

    // Ajouter les colonnes au TreeView si elles n'existent pas encore
    if (g_list_length(gtk_tree_view_get_columns(treeview)) == 0) {
        renderer = gtk_cell_renderer_text_new();
        gtk_tree_view_insert_column_with_attributes(treeview, -1, "Matricule", renderer, "text", 0, NULL);

        renderer = gtk_cell_renderer_text_new();
        gtk_tree_view_insert_column_with_attributes(treeview, -1, "Stationnement", renderer, "text", 1, NULL);

        renderer = gtk_cell_renderer_text_new();
        gtk_tree_view_insert_column_with_attributes(treeview, -1, "Durée", renderer, "text", 2, NULL);

        renderer = gtk_cell_renderer_text_new();
        gtk_tree_view_insert_column_with_attributes(treeview, -1, "Nature", renderer, "text", 3, NULL);

        renderer = gtk_cell_renderer_text_new();
        gtk_tree_view_insert_column_with_attributes(treeview, -1, "Abonnement", renderer, "text", 4, NULL);

        renderer = gtk_cell_renderer_text_new();
        gtk_tree_view_insert_column_with_attributes(treeview, -1, "Numéro", renderer, "text", 5, NULL);

        renderer = gtk_cell_renderer_text_new();
        gtk_tree_view_insert_column_with_attributes(treeview, -1, "Parking", renderer, "text", 6, NULL);
    }

    // Associer le modèle au TreeView
    gtk_tree_view_set_model(treeview, GTK_TREE_MODEL(store));
    g_object_unref(store); // Libérer le modèle
}

